# Numerologie

- [[Introducere|Introducere]]

## Documentatie modulara

- [[Vibratii/01-V-Index|Vibratii]]
- [[Vibratii Fundamentale/01-VF-Index|Vibratii Fundamentale]]
- [[Spirit si Karma/01-SK-Index|Spirit si Karma]]
- [[Matricea Datei de Nastere/01-MDN-Familie-Index|Matricea Datei de Nastere]]
- [[Nume/01-N-Index|Nume]]
- [[Ciclicitati/01-CIC-Index|Ciclicitati]]
- [[Relatii/01-REL-Index|Relatii]]
- [[Date de Intrare/01-DI-Index|Date de Intrare]]

> Documentatia modulara este noul punct de navigare. Notele legacy au fost
> mutate in [[../../Archive/Numerologie Legacy/README|arhiva Numerologie
> Legacy]], iar legaturile de mai jos raman active pentru compatibilitate.

## Vibratii

- [[Vibratia 0]]
- [[Vibratia 1]]
- [[Vibratia 2]]
- [[Vibratia 3]]
- [[Vibratia 4]]
- [[Vibratia 5]]
- [[Vibratia 6]]
- [[Vibratia 7]]
- [[Vibratia 8]]
- [[Vibratia 9]]
- [[Vibratia 11]]
- [[Vibratia 22]]
- [[Vibratia 33]]

## Vibratii Fundamentale

- [[Vibratie Interioara]]
- [[Vibratie Exterioara]]
- [[Vibratie Cosmica Fixa]]
- [[Vibratie Cosmica Variabila]]
- [[Vibratie Cosmica Totala]]
- [[Vibratie Globala]]

## Destin si Evolutie

- [[Vibratia Destinului]]
- [[Calea Destinului]]
- [[Soarta si Destin]]
- [[Lectii de Viata]]
- [[Aspecte de Indreptat]]
- [[Punti]]

## Karma

- [[Karma din Ziua Nasterii]]
- [[Karma din Luna Nasterii]]
- [[Karma din Calea Destinului]]

## Numere Personale

- [[Numarul de Exprimare]]
- [[Numarul Intim]]
- [[Numarul de Realizare]]
- [[Numarul Activ]]
- [[Numarul Ereditar]]
- [[Numarul Neamului]]
- [[Cod Numerologic Personal]]
- [[Influentele Numelui]]
- [[Codul Spiritului]]

## Matrici si Analize

- [[Matricea Datei de Nastere]]
- [[Matricea Numelui]]
- [[Matricea Numelui vs Matricea Datei de Nastere]]
- [[Figuri Geometrice]]
- [[Scara Bunastarii]]
- [[Fixatia]]
- [[Curgerea Energiei]]
- [[Caii Trasura si Vizitiul]]

## Cicluri si Etape de Viata

- [[Pinacluri - Oportunitati si Provocari]]
- [[Ciclul de 7 Ani]]
- [[Septagrama]]
- [[Ciclul de 9 Ani]]
- [[Ciclul de 12 Ani]]
- [[Anii Importanti Int-Ext]]

## Relatii

- [[Omuletul Relatiilor]]

## Sinteza si Aplicabilitate

- [[Deschidere spre Ezoterism]]
- [[Aplicabilitate Profesionala]]
- [[Concluzii]]

## Ajutoare

- [[Semnatura Astrala]]
- [[Directiile de Succes]]
- [[Triunghiul Financiar]]
- [[Patratul de Aur]]
