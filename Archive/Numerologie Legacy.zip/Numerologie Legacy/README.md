# Arhivă Numerologie Legacy

Acest director păstrează notele-sursă monolitice mutate din
`vault/Numerologie` după transpunerea lor în documentația modulară.

## Navigare

- [[Index|Index Numerologie Legacy]]

## Conținut

- 63 de note Markdown legacy, inclusiv vechiul `Index.md`;
- sursele istorice pentru conceptele din `vault/Numerologie`;
- `Concluzii.md`, păstrat ca anomalie legacy: conținutul său dublează
  `Codul Spiritului.md`, cu o diferență nesemnificativă de spațiere.

## Reguli

- documentația activă se accesează prin indexurile familiilor modulare din
  `vault/Numerologie`;
- notele din acest director nu se editează ca surse active;
- registrele de validare nu fac parte din arhivă;
- fișierele SVG de exemplu rămân în `vault/Numerologie`, deoarece sunt resurse
  active folosite de documentația modulară.
